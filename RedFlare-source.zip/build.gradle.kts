plugins {
    id("java")
}

group = "com.yourserver"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    // Real Paper 26.1.2 API - extracted directly from the actual server jar
    // (paper-26_2-10.jar) you uploaded, from:
    //   META-INF/libraries/io/papermc/paper/paper-api/26.1.2.build.74-stable/
    //     paper-api-26.1.2.build.74-stable.jar
    // Bundled here as a local file dependency instead of pulled from
    // repo.papermc.io at build time. This guarantees the exact API build
    // this compiles against is identical to the one your real server runs -
    // no version-string guessing, no risk of a mismatched snapshot.
    compileOnly(files("libs/paper-api-26.1.2.build.74-stable.jar"))
}

java {
    toolchain {
        // version.json inside your server jar reports java_version: 25
        languageVersion.set(JavaLanguageVersion.of(25))
    }
}

tasks.withType<Jar> {
    archiveBaseName.set("RedFlare")
}

tasks.processResources {
    duplicatesStrategy = DuplicatesStrategy.INCLUDE
}
