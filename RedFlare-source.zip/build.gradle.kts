plugins {
    id("java")
}

group = "com.yourserver"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    // Real Paper 26.1.2 API AND the libraries its own public class
    // hierarchy actually references (adventure-api, adventure-key,
    // examination-api, the maven-resolver family used by Paper's
    // PluginLoader API, etc.) - all extracted directly from
    // META-INF/libraries/ inside the actual server jar (paper-26_2-10.jar)
    // you uploaded, so versions match your real server exactly.
    //
    // First build attempt failed with "class file for
    // net.kyori.adventure.key.Namespaced not found" - JavaPlugin's type
    // hierarchy reaches into adventure-api, so it had to be on the compile
    // classpath too, not just paper-api itself.
    //
    // This libs/ folder is a trimmed set, not all 65 jars bundled in the
    // server: I computed the actual transitive class-reference closure
    // starting from paper-api's own bytecode (which jar-file provides each
    // class every paper-api class file references, repeated until no new
    // jars turn up) and kept only that closure - things like the bundled
    // MySQL driver, sqlite-jdbc, jline, spark, and velocity-native are real
    // server runtime dependencies but paper-api's public API surface never
    // references them, so they're not needed to compile a plugin and were
    // dropped to keep this small.
    compileOnly(fileTree("libs") { include("*.jar") })

    // The one library paper-api needs that is NOT bundled inside the server
    // jar (Paperclip downloads it separately at first server launch from
    // Maven Central, rather than shipping it locally). Resolved from Maven
    // Central here since GitHub Actions runners have normal internet access.
    // Version isn't build-critical: Guava's Preconditions/collections API
    // used by paper-api's public surface has been stable for years.
    compileOnly("com.google.guava:guava:33.3.1-jre")
}

java {
    toolchain {
        // version.json inside your server jar reports java_version: 25
        languageVersion.set(JavaLanguageVersion.of(25))
    }
}

tasks.withType<Jar> {
    archiveBaseName.set("RedFlare")
}

tasks.processResources {
    duplicatesStrategy = DuplicatesStrategy.INCLUDE
}
