rootProject.name = "RedFlare"
