package com.yourserver.redflare;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class DeathListener implements Listener {

    private final RedFlarePlugin plugin;
    private final FlareLauncher flareLauncher;

    public DeathListener(RedFlarePlugin plugin, FlareLauncher flareLauncher) {
        this.plugin = plugin;
        this.flareLauncher = flareLauncher;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        plugin.getLogger().info("Death flare triggered for " + player.getName() + ".");
        flareLauncher.launch(player.getLocation(), "death:" + player.getName());
    }
}
