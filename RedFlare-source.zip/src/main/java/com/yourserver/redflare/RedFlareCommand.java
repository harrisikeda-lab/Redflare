package com.yourserver.redflare;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RedFlareCommand implements CommandExecutor {

    private final RedFlarePlugin plugin;
    private final FlareLauncher flareLauncher;

    public RedFlareCommand(RedFlarePlugin plugin, FlareLauncher flareLauncher) {
        this.plugin = plugin;
        this.flareLauncher = flareLauncher;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use /redflare.");
            return true;
        }

        Player player = (Player) sender;
        plugin.getLogger().info("Manual /redflare used by " + player.getName() + ".");
        flareLauncher.launch(player.getLocation(), "manual:" + player.getName());
        player.sendMessage(ChatColor.RED + "Red flare launched!");
        return true;
    }
}
