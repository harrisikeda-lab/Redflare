package com.yourserver.redflare;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Handles launching and running a single red emergency flare:
 *  - Phase 1 (rise): a red/flame/smoke trail climbs from the origin to an apex.
 *  - Phase 2 (hold): a bright flare head burns in place for several minutes,
 *    with a continuously re-drawn thick red smoke column beneath it.
 *
 * Particles are sent directly per-player with force=true so they render at
 * long range and are not silently dropped by client-side particle limits.
 */
public class FlareLauncher {

    // --- Tunable parameters ---
    private static final int RISE_TICKS = 40;      // ~2 seconds to reach apex
    private static final double RISE_HEIGHT = 40.0; // blocks above the launch point
    private static final int HOLD_TICKS = 3600;     // 3 minutes burning at apex (20 ticks/sec)
    private static final int PARTICLE_PERIOD = 2;   // effect loop runs every 2 ticks (10/sec)
    private static final int SOUND_PERIOD = 100;    // loud bang every 5 seconds while holding
    private static final double COLUMN_STEP = 0.5;  // vertical spacing of column samples (denser = thicker)

    // Colours used for the column/head. Everything is red - no gray/black
    // smoke particles anywhere, so the column never fades to black once the
    // first burst of particles despawns. Size bumped up for a much thicker,
    // more solid-looking cloud of dust.
    private static final Particle.DustOptions BRIGHT_RED =
            new Particle.DustOptions(Color.fromRGB(255, 25, 25), 6.0F);
    private static final Particle.DustOptions DEEP_RED =
            new Particle.DustOptions(Color.fromRGB(160, 0, 0), 5.0F);

    private final RedFlarePlugin plugin;
    private final List<BukkitTask> activeTasks = new CopyOnWriteArrayList<>();

    public FlareLauncher(RedFlarePlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Launches a flare at the given location. Safe to call multiple times
     * concurrently (e.g. several players dying at once) - each flare runs
     * as its own independent scheduled task.
     */
    public void launch(Location origin, String reason) {
        World world = origin.getWorld();
        if (world == null) {
            return;
        }

        // Clamp the apex so it never tries to render above the world's build limit.
        double maxY = world.getMaxHeight() - 5;
        double apexY = Math.min(origin.getY() + RISE_HEIGHT, maxY);
        double actualRise = Math.max(apexY - origin.getY(), 5.0);
        int riseTicksForThis = (int) Math.max(10, Math.round(RISE_TICKS * (actualRise / RISE_HEIGHT)));

        plugin.getLogger().info("Flare launched (" + reason + ") at "
                + formatLoc(origin) + " in world '" + world.getName() + "'.");

        playLoudSound(origin, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 5.0F, 0.7F);

        FlareTask flareTask = new FlareTask(origin, actualRise, riseTicksForThis, reason);
        BukkitTask scheduled = plugin.getServer().getScheduler()
                .runTaskTimer(plugin, flareTask, 0L, PARTICLE_PERIOD);
        flareTask.setHandle(scheduled);
        activeTasks.add(scheduled);
    }

    /** Cancels every currently running flare. Called on plugin disable. */
    public void cancelAll() {
        for (BukkitTask task : activeTasks) {
            task.cancel();
        }
        activeTasks.clear();
    }

    // ------------------------------------------------------------------

    private final class FlareTask implements Runnable {
        private final Location origin;
        private final double actualRise;
        private final int riseTicksForThis;
        private final String reason;

        private int tick = 0;
        private boolean risingLogged = false;
        private boolean holdLogged = false;
        private BukkitTask handle;

        FlareTask(Location origin, double actualRise, int riseTicksForThis, String reason) {
            this.origin = origin;
            this.actualRise = actualRise;
            this.riseTicksForThis = riseTicksForThis;
            this.reason = reason;
        }

        void setHandle(BukkitTask handle) {
            this.handle = handle;
        }

        @Override
        public void run() {
            int t = tick++;

            if (t <= riseTicksForThis) {
                if (!risingLogged) {
                    risingLogged = true;
                    plugin.getLogger().info("Flare started rising (" + reason + ").");
                }
                double progress = (double) t / riseTicksForThis;
                Location head = origin.clone().add(0, actualRise * progress, 0);
                spawnRisingTrail(head);
                return;
            }

            if (!holdLogged) {
                holdLogged = true;
                plugin.getLogger().info("Flare reached apex, burning (" + reason + ").");
            }

            int holdTick = t - riseTicksForThis;
            Location head = origin.clone().add(0, actualRise, 0);
            spawnHoldEffects(head, origin);

            if (holdTick % SOUND_PERIOD == 0) {
                playLoudSound(head, Sound.ENTITY_GENERIC_EXPLODE, 3.0F, 1.4F);
            }

            if (holdTick >= HOLD_TICKS) {
                if (handle != null) {
                    handle.cancel();
                    activeTasks.remove(handle);
                }
                plugin.getLogger().info("Flare ended (" + reason + ") at " + formatLoc(origin) + ".");
            }
        }
    }

    // ------------------------------------------------------------------

    private void spawnRisingTrail(Location head) {
        List<Player> players = onlineInWorld(head.getWorld());
        for (Player player : players) {
            player.spawnParticle(Particle.DUST, head, 140, 0.3, 0.3, 0.3, 0, BRIGHT_RED, true);
            player.spawnParticle(Particle.DUST, head, 100, 0.35, 0.35, 0.35, 0, DEEP_RED, true);
            player.spawnParticle(Particle.FLAME, head, 50, 0.15, 0.15, 0.15, 0.01, null, true);
        }
    }

    private void spawnHoldEffects(Location head, Location origin) {
        World world = head.getWorld();
        List<Player> players = onlineInWorld(world);
        if (players.isEmpty()) {
            return;
        }

        for (Player player : players) {
            // Bright, thick red flare head - all DUST, so it never turns gray/black.
            player.spawnParticle(Particle.DUST, head, 550, 0.7, 0.7, 0.7, 0, BRIGHT_RED, true);
            player.spawnParticle(Particle.DUST, head, 350, 0.65, 0.65, 0.65, 0, DEEP_RED, true);
            player.spawnParticle(Particle.FLAME, head, 100, 0.4, 0.4, 0.4, 0.02, null, true);
            player.spawnParticle(Particle.LAVA, head, 30, 0.3, 0.3, 0.3, 0, null, true);
        }

        // Re-draw a thick red column every cycle from the ground up to the
        // flare head. Individual particles fade fast, so redrawing the whole
        // column each pass with a dense DUST cloud is what keeps it looking
        // continuous, thick, and consistently red the whole way up.
        double startY = origin.getY();
        double endY = head.getY();
        boolean brightRow = true;
        for (double y = startY; y <= endY; y += COLUMN_STEP) {
            Location point = new Location(world, head.getX(), y, head.getZ());
            Particle.DustOptions colour = brightRow ? BRIGHT_RED : DEEP_RED;
            brightRow = !brightRow;
            for (Player player : players) {
                player.spawnParticle(Particle.DUST, point, 90, 0.45, 0.3, 0.45, 0, colour, true);
            }
        }
    }

    private void playLoudSound(Location loc, Sound sound, float volume, float pitch) {
        for (Player player : onlineInWorld(loc.getWorld())) {
            player.playSound(loc, sound, SoundCategory.MASTER, volume, pitch);
        }
    }

    private List<Player> onlineInWorld(World world) {
        List<Player> result = new ArrayList<>();
        if (world == null) {
            return result;
        }
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (world.equals(player.getWorld())) {
                result.add(player);
            }
        }
        return result;
    }

    private String formatLoc(Location loc) {
        return "(" + (int) loc.getX() + ", " + (int) loc.getY() + ", " + (int) loc.getZ() + ")";
    }
}
