package com.yourserver.redflare;

import org.bukkit.ChatColor;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks combat tags: a player who has recently dealt or taken damage
 * to/from another player is "tagged" for TAG_DURATION_MILLIS. While tagged,
 * a red boss bar is shown at the top of their screen counting down, so it's
 * obvious logging out right now will kill them (see {@link CombatListener}).
 */
public class CombatManager {

    private static final long TAG_DURATION_MILLIS = 15_000L; // 15 seconds
    private static final int UPDATE_PERIOD_TICKS = 4;        // 5 updates/sec - smooth countdown

    private final RedFlarePlugin plugin;
    private final Map<UUID, Long> taggedUntil = new ConcurrentHashMap<>();
    private final Map<UUID, BossBar> bossBars = new ConcurrentHashMap<>();
    private BukkitTask updaterTask;

    public CombatManager(RedFlarePlugin plugin) {
        this.plugin = plugin;
    }

    /** Starts the recurring task that keeps every tagged player's boss bar up to date. */
    public void startUpdater() {
        updaterTask = plugin.getServer().getScheduler()
                .runTaskTimer(plugin, this::tickBossBars, 0L, UPDATE_PERIOD_TICKS);
    }

    /** Cancels the updater and removes every currently shown boss bar. Called on plugin disable. */
    public void shutdown() {
        if (updaterTask != null) {
            updaterTask.cancel();
        }
        for (BossBar bar : bossBars.values()) {
            bar.removeAll();
        }
        bossBars.clear();
        taggedUntil.clear();
    }

    public void tag(Player player) {
        UUID id = player.getUniqueId();
        taggedUntil.put(id, System.currentTimeMillis() + TAG_DURATION_MILLIS);

        BossBar bar = bossBars.get(id);
        if (bar == null) {
            bar = plugin.getServer().createBossBar(
                    ChatColor.RED + "" + ChatColor.BOLD + "COMBAT - logging out will kill you!",
                    BarColor.RED, BarStyle.SOLID);
            bar.addPlayer(player);
            bar.setProgress(1.0);
            bossBars.put(id, bar);
        }
    }

    public boolean isTagged(UUID playerId) {
        Long until = taggedUntil.get(playerId);
        if (until == null) {
            return false;
        }
        if (System.currentTimeMillis() > until) {
            untag(playerId);
            return false;
        }
        return true;
    }

    /** Clears a player's tag and hides their boss bar immediately (e.g. on death). */
    public void clear(UUID playerId) {
        untag(playerId);
    }

    private void untag(UUID playerId) {
        taggedUntil.remove(playerId);
        BossBar bar = bossBars.remove(playerId);
        if (bar != null) {
            bar.removeAll();
        }
    }

    private void tickBossBars() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : taggedUntil.entrySet()) {
            UUID id = entry.getKey();
            long remainingMillis = entry.getValue() - now;

            if (remainingMillis <= 0) {
                untag(id);
                continue;
            }

            BossBar bar = bossBars.get(id);
            if (bar == null) {
                continue;
            }

            double progress = Math.max(0.0, Math.min(1.0, remainingMillis / (double) TAG_DURATION_MILLIS));
            bar.setProgress(progress);

            long secondsLeft = (remainingMillis + 999) / 1000; // round up
            bar.setTitle(ChatColor.RED + "" + ChatColor.BOLD
                    + "COMBAT - " + secondsLeft + "s - logging out will kill you!");
        }
    }
}
