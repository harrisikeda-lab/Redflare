package com.yourserver.redflare;

import org.bukkit.plugin.java.JavaPlugin;

public final class RedFlarePlugin extends JavaPlugin {

    private FlareLauncher flareLauncher;
    private CombatManager combatManager;

    @Override
    public void onEnable() {
        this.flareLauncher = new FlareLauncher(this);
        this.combatManager = new CombatManager(this);
        this.combatManager.startUpdater();

        getServer().getPluginManager().registerEvents(new DeathListener(this, flareLauncher), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this, combatManager), this);
        getServer().getPluginManager().registerEvents(new LootChestListener(this, combatManager), this);

        RedFlareCommand executor = new RedFlareCommand(this, flareLauncher);
        getCommand("redflare").setExecutor(executor);

        getLogger().info("RedFlare plugin enabled.");
    }

    @Override
    public void onDisable() {
        if (flareLauncher != null) {
            flareLauncher.cancelAll();
        }
        if (combatManager != null) {
            combatManager.shutdown();
        }
        getLogger().info("RedFlare plugin disabled.");
    }
}
