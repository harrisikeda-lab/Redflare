package com.yourserver.redflare;

import org.bukkit.plugin.java.JavaPlugin;

public final class RedFlarePlugin extends JavaPlugin {

    private FlareLauncher flareLauncher;

    @Override
    public void onEnable() {
        this.flareLauncher = new FlareLauncher(this);

        getServer().getPluginManager().registerEvents(new DeathListener(this, flareLauncher), this);

        RedFlareCommand executor = new RedFlareCommand(this, flareLauncher);
        getCommand("redflare").setExecutor(executor);

        getLogger().info("RedFlare plugin enabled.");
    }

    @Override
    public void onDisable() {
        if (flareLauncher != null) {
            flareLauncher.cancelAll();
        }
        getLogger().info("RedFlare plugin disabled.");
    }
}
