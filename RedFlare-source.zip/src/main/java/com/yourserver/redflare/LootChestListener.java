package com.yourserver.redflare;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Chest;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Instead of letting a dead player's items scatter on the ground, this
 * collects everything they would have dropped (plus a head item for the
 * player) and places it all into a double chest at the death location.
 */
public class LootChestListener implements Listener {

    // Directions tried, in order, when looking for a spot to place the
    // double chest. Each is paired with a facing perpendicular to it so the
    // two chest halves connect correctly (see chestTypeFor()).
    private static final BlockFace[] SEARCH_OFFSETS = {
            BlockFace.EAST, BlockFace.WEST, BlockFace.SOUTH, BlockFace.NORTH
    };
    private static final int MAX_VERTICAL_SEARCH = 3;

    private final RedFlarePlugin plugin;
    private final CombatManager combatManager;

    public LootChestListener(RedFlarePlugin plugin, CombatManager combatManager) {
        this.plugin = plugin;
        this.combatManager = combatManager;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        combatManager.clear(player.getUniqueId());

        List<ItemStack> items = new ArrayList<>(event.getDrops());
        event.getDrops().clear();
        event.setKeepInventory(false);

        items.add(buildHeadItem(player));

        placeLootChest(player.getLocation(), items, player.getName());
        plugin.getLogger().info("Loot chest created for " + player.getName() + "'s death.");
    }

    private ItemStack buildHeadItem(Player player) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(player);
            meta.setDisplayName(ChatColor.RED + player.getName() + "'s Head");
            head.setItemMeta(meta);
        }
        return head;
    }

    private void placeLootChest(Location origin, List<ItemStack> items, String playerName) {
        World world = origin.getWorld();
        if (world == null) {
            return;
        }

        Block anchor = null;
        Block neighbor = null;
        BlockFace facing = null;
        BlockFace offset = null;

        searching:
        for (int dy = 0; dy <= MAX_VERTICAL_SEARCH; dy++) {
            Block candidateAnchor = world.getBlockAt(
                    origin.getBlockX(), origin.getBlockY() + dy, origin.getBlockZ());
            for (BlockFace candidateOffset : SEARCH_OFFSETS) {
                Block candidateNeighbor = candidateAnchor.getRelative(candidateOffset);
                if (isReplaceable(candidateAnchor) && isReplaceable(candidateNeighbor)) {
                    anchor = candidateAnchor;
                    neighbor = candidateNeighbor;
                    offset = candidateOffset;
                    facing = (candidateOffset == BlockFace.EAST || candidateOffset == BlockFace.WEST)
                            ? BlockFace.NORTH : BlockFace.EAST;
                    break searching;
                }
            }
        }

        if (anchor == null) {
            // Nowhere clear was found - place at the death spot anyway so
            // the loot is never silently lost. This may overwrite blocks.
            anchor = world.getBlockAt(origin.getBlockX(), origin.getBlockY(), origin.getBlockZ());
            neighbor = anchor.getRelative(BlockFace.EAST);
            offset = BlockFace.EAST;
            facing = BlockFace.NORTH;
            plugin.getLogger().info("Loot chest spot was obstructed for "
                    + playerName + " - placing anyway.");
        }

        Chest.Type anchorType = (offset == clockwise(facing)) ? Chest.Type.LEFT : Chest.Type.RIGHT;
        Chest.Type neighborType = (anchorType == Chest.Type.LEFT) ? Chest.Type.RIGHT : Chest.Type.LEFT;

        setChestBlock(anchor, facing, anchorType);
        setChestBlock(neighbor, facing, neighborType);

        BlockState state = anchor.getState();
        if (!(state instanceof org.bukkit.block.Chest)) {
            plugin.getLogger().warning("Loot chest creation failed for "
                    + playerName + " - dropping items normally instead.");
            for (ItemStack item : items) {
                if (item != null) {
                    world.dropItemNaturally(origin, item);
                }
            }
            return;
        }

        Inventory inventory = ((org.bukkit.block.Chest) state).getInventory();
        for (ItemStack item : items) {
            if (item == null || item.getType() == Material.AIR) {
                continue;
            }
            Map<Integer, ItemStack> overflow = inventory.addItem(item);
            for (ItemStack leftover : overflow.values()) {
                world.dropItemNaturally(origin, leftover);
            }
        }
    }

    private void setChestBlock(Block block, BlockFace facing, Chest.Type type) {
        BlockData data = plugin.getServer().createBlockData(Material.CHEST);
        if (data instanceof Chest) {
            Chest chestData = (Chest) data;
            chestData.setFacing(facing);
            chestData.setType(type);
            block.setBlockData(chestData, false);
        }
    }

    private boolean isReplaceable(Block block) {
        Material type = block.getType();
        return type.isAir() || type == Material.WATER || type == Material.LAVA;
    }

    /** Standard horizontal clockwise rotation, used to work out which chest
     *  half (LEFT/RIGHT) each block should be for the two to merge. */
    private BlockFace clockwise(BlockFace face) {
        switch (face) {
            case NORTH: return BlockFace.EAST;
            case EAST: return BlockFace.SOUTH;
            case SOUTH: return BlockFace.WEST;
            case WEST: return BlockFace.NORTH;
            default: return face;
        }
    }
}
